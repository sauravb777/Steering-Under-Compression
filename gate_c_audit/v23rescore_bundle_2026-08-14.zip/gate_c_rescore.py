#!/usr/bin/env python3
"""Gate C: v2.3.1 offline rescore of the 45 sentiment COMPLETE files +
validation against the 2026-07-15 fliplist. Writes *_v23rescore_* siblings."""
import json, re, glob
from pathlib import Path

# --- parser v2.3.1, verbatim from steerquant_phase0_harness.py (2026-07-17) ---
_H = re.compile(r"####\s*\$?\s*([-+]?[\d.,]+)")
_B = re.compile(r"\\boxed\{\s*\$?\s*([-+]?[\d.,]+)\s*\}")
_P = re.compile(r"answer\s*(?:is|:)[\s:]*\$?\s*([-+]?[\d.,]+)", re.IGNORECASE)
_T = re.compile(r"^[\s*_`>]*[<\(\[\{]?\s*\$?\s*([-+]?\d[\d.,]*)\s*[>\)\]\}]?[\s*_`.)\]]*$")

def norm(s):
    s = s.strip().replace(",", "").replace("$", "").rstrip(".")
    try: f = float(s)
    except ValueError: return None
    if f != f or f in (float("inf"), float("-inf")): return None
    return str(int(f)) if f == int(f) else repr(f)

def parse(text):
    for rx in (_H, _B, _P):
        for m in reversed(list(rx.finditer(text))):
            v = norm(m.group(1))
            if v is not None: return v
    for line in reversed(text.splitlines()):
        if not line.strip(): continue
        m = _T.match(line)
        if m: return norm(m.group(1))
        break
    return None

# --- golds ---
from datasets import load_dataset
ds = load_dataset("openai/gsm8k", "main", split="test")

SRC = "/mnt/user-data/uploads/Claude/projects/steering-quantization/results"
files = sorted(f for f in glob.glob(f"{SRC}/*_sentiment_*_COMPLETE_*.json"))
print("files:", len(files))
guard_failures, my_flips, per_file = [], [], {}
for fp in files:
    data = json.loads(Path(fp).read_text(encoding="utf-8"))
    meta = data["meta"]
    idx = meta["resample"]["mmlu_item_indices"]
    m = len(idx)
    base = ds.select(range(min(m, len(ds))))
    golds = [parse(base[int(i) % len(base)]["answer"]) for i in idx]
    nfl = 0
    for block in data["by_alpha"]:
        texts, items, eos = (block.get("capability_texts"),
                             block.get("capability_mmlu_items"),
                             block.get("capability_eos_flags"))
        if not (texts and items and eos): continue
        L = min(len(texts), len(items), len(eos))
        new_items, new_fail = [], []
        for j in range(L):
            pred = parse(texts[j]); e = int(eos[j]); old = int(items[j])
            new = 1 if (e == 1 and golds[j] is not None and pred == golds[j]) else 0
            if old == 1 and not new:
                guard_failures.append((Path(fp).name, block.get("alpha"), j, golds[j], pred, e))
            if new != old:
                nfl += 1
                my_flips.append(f"{Path(fp).stem}|a{block.get('alpha')}|i{j}")
            new_items.append(new); new_fail.append(1 if (pred is None or e == 0) else 0)
        block["capability_mmlu_items"] = new_items
        block["capability_mmlu"] = sum(new_items) / L
        block["capability_failure_rate"] = sum(new_fail) / L
    per_file[Path(fp).name] = nfl
    meta["gsm8k_parser"] = str(meta.get("gsm8k_parser", "")) + "+v2.3.1-rescore-20260814"
    out = Path("results") / Path(fp).name.replace("_COMPLETE_", "_COMPLETE_v23rescore_")
    out.write_text(json.dumps(data), encoding="utf-8")

print("total flips (mine):", len(my_flips))
if guard_failures:
    print("GUARD FAILURES (old-correct not re-verified):", len(guard_failures))
    for g in guard_failures[:8]: print("  ", g)
else:
    print("guard: all old-correct items re-verify under v2.3.1")

# --- validate against the 07-15 fliplist ---
ref = json.loads(Path("/mnt/user-data/uploads/Claude/projects/steering-quantization/SteerQuant_v23_fliplist_2026-07-15.json").read_text(encoding="utf-8"))
ref_ids = set(f["id"] for f in ref["flips"])
mine = set(my_flips)
print(f"reference fliplist: {len(ref_ids)} flips; mine: {len(mine)}")
print("  missing from mine:", len(ref_ids - mine), "| extra in mine:", len(mine - ref_ids))
for x in list(ref_ids - mine)[:5]: print("   ref-only:", x)
for x in list(mine - ref_ids)[:5]: print("   mine-only:", x)
